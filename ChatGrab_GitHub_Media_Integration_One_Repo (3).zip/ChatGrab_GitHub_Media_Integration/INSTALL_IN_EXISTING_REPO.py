#!/usr/bin/env python3
# ChatGrab Media integration: run from root of a cloned DrDoohicky/CHATGRAB2 repository.
from pathlib import Path
import shutil, sys

ROOT=Path.cwd()
PKG=Path(__file__).resolve().parent
S=ROOT/'src'/'components'
required=[ROOT/'package.json',ROOT/'src'/'App.tsx',S/'Header.tsx',S/'WorkspaceNavigation.tsx',S/'ChatGrabDashboard.tsx']
if not all(p.is_file() for p in required):
    sys.exit('ERROR: Run this installer from the root of an existing CHATGRAB2 checkout (package.json and src/App.tsx required). Nothing changed.')

old={p:p.read_text(encoding='utf8') for p in required[1:]}
planned={}
def change(path,new,label):
    if new==old[path] and "media" not in label.lower():
        raise ValueError('Anchor not found: '+label+' in '+str(path))
    planned[path]=new

def required_replace(src,a,b,label):
    if a in src: return src.replace(a,b,1)
    if b in src: return src
    raise ValueError('Cannot safely patch '+label+'. Source differs from expected. Nothing changed.')

try:
    dashboard=S/'ChatGrabDashboard.tsx'; s=old[dashboard]
    if "'media'" not in s.split('export type CGPage',1)[1].split(';',1)[0]:
        s=required_replace(s," | 'bridge';"," | 'bridge' | 'media';",'CGPage union') if " | 'bridge';" in s else required_replace(s," | 'settings';"," | 'settings' | 'media';",'CGPage union')
    if "import { Film" not in s and " Film," not in s:
        s=required_replace(s,'import { ArrowRight,','import { Film, ArrowRight,','dashboard icon import')
    if "<h2>Media library</h2>" not in s:
        marker='<div className="cg-resource-grid">'
        snippet='''<div className="cg-resource-grid">
      <button className="cg-resource cg-media-card" onClick={()=>onNavigate('media')}><div><Film className="cg-resource-icon"/><h2>Media library</h2><p>Watch the explainer, explore the Continuity Framework and browse illustrated tutorials.</p><span>Open Media <ArrowRight size={17}/></span></div><div aria-hidden="true" className="cg-media-shortcut-art"><Film size={75}/></div></button>'''
        s=required_replace(s,marker,snippet,'workspace Media shortcut')
    if 'media: [' not in s and '  settings: [' in s:
        s=required_replace(s,'  settings: [','  media: [\'Media library\', \'Explore the explainer video and framework materials.\'],\n  settings: [','details media')
    if 'media: () => onNavigate' not in s and 'settings: onAccount,' in s:
        s=required_replace(s,'settings: onAccount,','media: () => onNavigate(\'media\'), settings: onAccount,','action mapping')
    planned[dashboard]=s

    nav=S/'WorkspaceNavigation.tsx'; s=old[nav]
    if 'Film' not in s.split('from \'lucide-react\'',1)[0]:
        s=required_replace(s,'Images,Download','Images,Film,Download','sidebar icons')
    if "['media','Media'" not in s:
        s=required_replace(s,"['export','Export',Download],","['export','Export',Download],['media','Media',Film],",'sidebar Media link')
    planned[nav]=s

    header=S/'Header.tsx'; s=old[header]
    if 'Film' not in s.split('from \'lucide-react\'',1)[0]:
        s=required_replace(s,'Images, Download','Images, Film, Download','header icon')
    if "id: 'media'" not in s:
        s=required_replace(s,"{ id: 'export', label: 'Export', icon: Download, action: () => onNavigate('export') },","{ id: 'export', label: 'Export', icon: Download, action: () => onNavigate('export') },\n    { id: 'media', label: 'Media', icon: Film, action: () => onNavigate('media') },",'top navigation Media link')
    planned[header]=s

    app=ROOT/'src'/'App.tsx'; s=old[app]
    if "import { MediaLibrary }" not in s:
        s=required_replace(s,"import { WorkspaceNavigation } from './components/WorkspaceNavigation';","import { WorkspaceNavigation } from './components/WorkspaceNavigation';\nimport { MediaLibrary } from './components/MediaLibrary';",'Media component import')
    if "import './components/media-library.css'" not in s:
        s=required_replace(s,"import './components/workspace-navigation.css';","import './components/workspace-navigation.css';\nimport './components/media-library.css';",'Media CSS import')
    if "page === 'media' ?" not in s:
        s=required_replace(s,"        ) : page === 'guide' ? (","        ) : page === 'media' ? (\n          <MediaLibrary onTutorial={()=>window.location.assign('/?page=tutorial')} onCapture={()=>openPage('capture')}/>\n        ) : page === 'guide' ? (",'Media route')
    # Query route support after refresh: existing app maps tutorial->guide; insert support for media
    marker="const initialPage=():CGPage=>{const page=new URLSearchParams(window.location.search).get('page');"
    if marker in s and "page==='media'" not in s.split('const initialNavigationPage',1)[0]:
        s=required_replace(s,marker,marker+"if(page==='media')return 'media';",'direct Media URL')
    planned[app]=s
except ValueError as exc:
    sys.exit('ABORTED without writing: '+str(exc))

# Validate that unchanged source receives targeted safe patches before writing anything.
assets=PKG/'repo-assets'/'public'/'media'
assert (assets/'ChatGrab_Continuity_Framework.pdf').is_file()
new_component=PKG/'source-additions'/'src'/'components'
assert (new_component/'MediaLibrary.tsx').is_file()
for dst,body in planned.items():
    dst.write_text(body,encoding='utf8')
shutil.copy2(new_component/'MediaLibrary.tsx', S/'MediaLibrary.tsx')
shutil.copy2(new_component/'media-library.css', S/'media-library.css')
public=ROOT/'public'/'media'
public.mkdir(parents=True,exist_ok=True)
shutil.copy2(assets/'ChatGrab_Continuity_Framework.pdf',public/'ChatGrab_Continuity_Framework.pdf')
(public/'previews').mkdir(exist_ok=True)
for p in (assets/'previews').glob('*.jpg'):shutil.copy2(p,public/'previews'/p.name)
print('SUCCESS: Media page, top/side/home navigation and framework assets installed into existing repo.')
print('No video, existing tutorial card, library data, server route or authentication file was replaced.')
print('Next: npm install && npm run build; npm test if available; then commit and push to your current repo branch.')
