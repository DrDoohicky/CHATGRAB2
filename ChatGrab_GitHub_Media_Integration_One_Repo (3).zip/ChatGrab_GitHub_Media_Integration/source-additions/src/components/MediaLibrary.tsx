import React from 'react';
import { ArrowRight, BookOpen, ExternalLink, FileText, Film, Images } from 'lucide-react';
import './media-library.css';

const chapterData = [
  ['Capture', 'tutorial', 'Public share link and original transcript'],
  ['Provenance', 'provenance', 'Separate original source and derived insights'],
  ['Contextual analysis', 'analytics', 'Review contradictions, themes and evidence'],
  ['Knowledge evolution', 'evolution', 'Understand chronology and changed decisions'],
  ['Evidence', 'evidence', 'Distinguish representation, artifact and behavior'],
  ['Reintegration', 'reintegration', 'Select source, destination and rationale'],
  ['Professional utility', 'utility', 'Explore possible applications']
] as const;
const pdf = '/media/ChatGrab_Continuity_Framework.pdf';
export function MediaLibrary({onTutorial,onCapture}:{onTutorial:()=>void;onCapture:()=>void}) {
  return <main className="cg-media-library" aria-label="ChatGrab Media Library">
    <header className="cg-media-heading"><span>CHATGRAB MEDIA &amp; EXPLAINERS</span>
      <h1>See how the context connects.</h1>
      <p>Watch the original explainer, read the Continuity Framework, and explore the illustrated tutorial. These resources explain concepts and workflows; they are not proof of unverified functionality.</p>
    </header>
    <div className="cg-media-hero">
      <section className="cg-media-video"><div className="cg-media-card-head"><Film size={22}/><div><small>FEATURED VIDEO · 9 MIN 50 SEC</small><h2>ChatGrab: Power Companion</h2></div></div>
        <video src="/video/ChatGrab_Power_Companion.mp4" controls playsInline preload="metadata" aria-label="ChatGrab Power Companion explainer" />
        <p>From scattered conversations to evidence-aware continuity.</p>
      </section>
      <section className="cg-media-framework"><div className="cg-media-card-head"><FileText size={22}/><div><small>10-SLIDE FRAMEWORK</small><h2>ChatGrab and the Path to Continuity</h2></div></div>
        <a href={pdf} target="_blank" rel="noopener noreferrer" aria-label="Open 10-page Path to Continuity PDF"><img src="/media/previews/framework-slide-02.jpg" alt="Seven-stage continuity map, from Capture through Utility" loading="lazy" /></a>
        <div className="cg-media-buttons"><a href={pdf} target="_blank" rel="noopener noreferrer"><ExternalLink size={17}/> Open PDF</a><a href={pdf} download="ChatGrab_Continuity_Framework.pdf"><FileText size={17}/> Save PDF</a></div>
      </section>
    </div>
    <section className="cg-media-explore"><div className="cg-media-section-heading"><BookOpen size={23}/><div><h2>Explore the tutorial</h2><p>Seven sections, 26 redesigned standalone illustrated cards.</p></div></div>
      <div className="cg-media-chapters">{chapterData.map(([name,id,summary])=><button key={id} onClick={()=>{window.location.assign('/?page=tutorial#guide-'+id);}}><strong>{name}</strong><span>{summary}</span><ArrowRight size={17}/></button>)}</div>
      <div className="cg-media-buttons"><button type="button" onClick={onTutorial}><Images size={17}/> Open complete illustrated tutorial</button></div>
    </section>
    <section className="cg-media-preview"><div className="cg-media-section-heading"><FileText size={23}/><h2>Featured framework slides</h2></div>
      <div>{([['01','Opening'],['05','Contextual analyses'],['07','Evidence'],['08','Reintegration'],['10','Evidentiary standard']] as const).map(([n,title])=><a key={n} href={pdf} target="_blank" rel="noopener noreferrer"><img src={'/media/previews/framework-slide-'+n+'.jpg'} alt={title+' slide from ChatGrab Continuity Framework'} loading="lazy"/><span>{title} <ExternalLink size={13}/></span></a>)}</div>
    </section>
    <footer className="cg-media-bottom"><p><strong>Preserve the original.</strong> Reconstruct the context. Validate the evidence. Reintegrate what matters.</p><button type="button" onClick={onCapture}>Capture a conversation <ArrowRight size={18}/></button></footer>
  </main>;
}
