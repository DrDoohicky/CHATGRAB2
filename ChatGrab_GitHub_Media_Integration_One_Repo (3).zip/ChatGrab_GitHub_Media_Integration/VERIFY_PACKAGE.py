from pathlib import Path
from PIL import Image
p=Path(__file__).resolve().parent
assets=p/'repo-assets'/'public'/'media'
assert (assets/'ChatGrab_Continuity_Framework.pdf').read_bytes()[:5]==b'%PDF-'
assert len(list((assets/'previews').glob('*.jpg')))==6
for f in (assets/'previews').glob('*.jpg'):
    with Image.open(f) as im:im.verify()
print('PASS: PDF signature and six image previews. This is not a website build or browser test.')
