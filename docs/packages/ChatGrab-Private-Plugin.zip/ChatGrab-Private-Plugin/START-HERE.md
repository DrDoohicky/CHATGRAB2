# ChatGrab private connection

In ChatGPT Plugins, add a custom MCP server named ChatGrab.
URL: https://chatgrab.app/api/mcp
Authentication: None
Review the tools and choose Create as a plugin.

Then select ChatGrab in a new chat and ask:
Use ChatGrab to check its connection status, then give me its workspace link.

This archive does not install itself or provide native conversation capture.
The endpoint already serves public read-only status and workspace links.
No OpenAI API key or payment is needed for these tools. Host policies apply.
See plugins/chatgrab/README.md for the full host acceptance steps.
The local marketplace is an optional desktop authoring route, separate from
the direct custom-MCP connection. Do not publish the plugin publicly.
