#!/usr/bin/env python3
"""Opt-in patch: wire the existing ChatGrab React analysis route to the no-key manual review page.
Run from anywhere: python tools/apply_manual_analysis.py, after copying this overlay into repo root.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'src/App.tsx'
if not APP.exists():
    print('ERROR: src/App.tsx not found. Run only in a checked-out CHATGRAB2 repository.',file=sys.stderr);sys.exit(2)
if not (ROOT/'public/manual-analysis.html').exists():
    print('ERROR: public/manual-analysis.html is absent',file=sys.stderr);sys.exit(2)
s=APP.read_text(encoding='utf-8')
if '<iframe title="ChatGrab manual ChatGPT and Gemini analysis"' in s:
    print('No change: manual analysis route already integrated.');sys.exit(0)
# Change the deep link so ?page=analyze opens Analyze, not an empty workspace.
old="['workspace','analyze'].includes(page||'')?'workspace':'capture'"
new="page==='analyze'?'analyze':page==='workspace'?'workspace':'capture'"
if old not in s:
    print('ERROR: Unknown initialPage layout. Aborting without modification.',file=sys.stderr);sys.exit(2)
s=s.replace(old,new,1)
# The existing analytics workspace remains available under ?page=workspace.
old="const anchor=next==='analyze'?'workspace-analytics':next==='reintegrate'?'workspace-reintegration':null;"
new="const anchor=next==='reintegrate'?'workspace-reintegration':null;"
if old not in s:
    print('ERROR: Unknown openPage layout. Aborting without modification.',file=sys.stderr);sys.exit(2)
s=s.replace(old,new,1)
# Insert a genuine, functioning no-key manual analysis view before the normal guide route.
anchor=") : page === 'guide' ? ("
view=""") : page === 'analyze' ? (
          <section className=\"cg-destination\" aria-label=\"Manual ChatGPT analysis\">
            <iframe title=\"ChatGrab manual ChatGPT and Gemini analysis\" src=\"/manual-analysis.html\" style={{width:'100%',minHeight:'1250px',border:0,borderRadius:18,background:'#f0f6fd'}} loading=\"eager\" />
          </section>
        ) : page === 'guide' ? ("""
if anchor not in s:
    print('ERROR: Guide route anchor missing. Aborting without modification.',file=sys.stderr);sys.exit(2)
s=s.replace(anchor,view,1)
# Make the primary dashboard's Analyze action open the analysis workflow too.
existing="onAnalyze={()=>{if(activeThread){setWorkspaceTab('insights');openPage('capture');}else{requestedThreadTab.current='insights';setIsCorpusOpen(true);}}}"
if existing in s:s=s.replace(existing,"onAnalyze={()=>openPage('analyze')}")
else:print('NOTE: dashboard Analyze callback pattern changed; check its action after installation.')
# Avoid the old deep-link scroll behavior triggering on Analyze page.
old="if(new URLSearchParams(window.location.search).get('page')==='analyze'){const frame=requestAnimationFrame(()=>document.getElementById('workspace-analytics')?.scrollIntoView({block:'start'}));return()=>cancelAnimationFrame(frame);}"
if old in s:s=s.replace(old,"if(new URLSearchParams(window.location.search).get('page')==='analyze'){return;}")
backup=APP.with_suffix('.tsx.before-manual-analysis.bak')
if not backup.exists():backup.write_text(APP.read_text(encoding='utf-8'),encoding='utf-8')
APP.write_text(s,encoding='utf-8')
print('SUCCESS: React Analyze route now embeds /manual-analysis.html; original full source-linked workbench remains on Workspace. Backup:',backup.name)
