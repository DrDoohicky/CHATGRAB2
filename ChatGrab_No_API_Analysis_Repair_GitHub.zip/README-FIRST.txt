CHATGRAB — NO-API ANALYSIS REPAIR
Target: DrDoohicky/CHATGRAB2, THE SAME repo and existing Vercel app.
No Codex credits or new hosting required.

WHAT ACTUALLY WORKS
- Self-contained /manual-analysis.html page.
- Paste a conversation or excerpt you choose.
- Select summary / decisions / contradictions / evolution / evidence / project status.
- Generate a context-grounded ChatGPT request, copy it, open your own ChatGPT account.
- Paste the response into ChatGrab; optionally prepare and import a Gemini second opinion.
- Export a complete JSON packet preserving original source, prompts, imported answers and hashes.
- NO key, unauthorized ChatGPT login, invisible provider requests, or automatic data transmission.
- The original source-linked AIReviewWorkbench remains available in the main Workspace.

IMPORTANT: GITHUB DOES NOT UNZIP ZIP FILES YOU UPLOAD.

EASIEST PATH (1 FILE, NO INSTALLER NEEDED):
1. Extract this ZIP locally (do not upload ZIP itself to GitHub).
2. In the GitHub web UI of DrDoohicky/CHATGRAB2, switch to the branch that actually drives your Vercel deployment. Current known published release: 94b83dd5a8d0bab8ae130f567e19bd4d0baf17b8. Do NOT assume main is the deployed branch.
3. Open the public/ folder and choose Add file > Upload files.
4. Upload ONLY the extracted public/manual-analysis.html file, then commit.
5. After Vercel deploys that branch, open: https://chatgrab-analysis-archiver.vercel.app/manual-analysis.html
The page works independently. This path does NOT change the existing Analyze button yet.

FULL INTEGRATION (DIRECT WORKSPACE/ANALYZE BUTTON):
1. Check out the CURRENT deployed ChatGrab source branch on your computer.
2. Extract this ZIP into the repository root, so it contains public/manual-analysis.html and tools/apply_manual_analysis.py.
3. Run: python tools/apply_manual_analysis.py
4. Check the changes to src/App.tsx, then run: npm install && npm run lint && npm run build.
5. Commit the public file, tools script, and src/App.tsx, then push the same branch Vercel deploys.
6. Test both /manual-analysis.html AND /?page=analyze. Existing Workspace remains under /?page=workspace.
7. Don't commit src/App.tsx.before-manual-analysis.bak; it is a local backup.

LIMITATIONS
- The standalone manual page does not automatically read ChatGrab localStorage or uploaded library records. You paste selected source text.
- Response attribution and factual correctness are NOT verified; source and answer SHA-256 digests attest to the text bundled on export only.
- This is not OAuth, ChatGPT API access, automatic Gemini API use, or account integration.
- Nothing is published until the correct branch builds and Vercel deploys; verify actual live pages before declaring PASS.
- The repository's more advanced manual source-linked workflow already exists in src/components/AIReviewWorkbench.tsx with literal source citation checks. The new page makes basic analysis discoverable without requiring that setup.
